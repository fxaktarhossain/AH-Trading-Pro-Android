package com.ahtradingpro.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://ahtradingpro.com";
    private static final int FILE_CHOOSER = 701;
    private WebView webView;
    private FrameLayout loadingOverlay;
    private ImageView loadingLogo;
    private ProgressBar loadingSpinner;
    private ValueCallback<Uri[]> fileCallback;
    private SoundPool soundPool;
    private int clickSound;
    private boolean clickSoundReady = false;
    private long lastClickSoundAt = 0L;
    private float touchDownX;
    private float touchDownY;
    private long touchDownAt;
    private boolean soundEnabled = true;
    private boolean banglaEnabled = false;
    private Translator translator;
    private SharedPreferences prefs;
    private TextView languageButton;
    private ImageButton soundButton;
    private final Handler loadingHandler = new Handler(Looper.getMainLooper());
    private final Runnable forceHideLoading = this::hideLoadingWithFade;
    private boolean loadingVisible = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(2,6,13));
        getWindow().setNavigationBarColor(Color.rgb(2,6,13));

        prefs = getSharedPreferences("ahtradingpro", MODE_PRIVATE);
        soundEnabled = prefs.getBoolean("sound", true);
        banglaEnabled = prefs.getBoolean("bangla", false);
        setupSound();
        setupTranslator();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2,6,13));

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        root.addView(shell, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout toolbar = buildToolbar();
        shell.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(54)));

        webView = new WebView(this);
        shell.addView(webView, new LinearLayout.LayoutParams(-1,0,1));
        setupWebView();
        installWebViewTouchSound();

        loadingOverlay = buildLoadingOverlay();
        root.addView(loadingOverlay, new FrameLayout.LayoutParams(-1,-1));

        setContentView(root);
        applySystemBarSafeArea(root);

        if (!isOnline()) {
            showOffline();
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    private LinearLayout buildToolbar() {
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(10),0,dp(8),0);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(2,6,13), Color.rgb(7,16,29)});
        toolbar.setBackground(bg);

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.logo_mark);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        toolbar.addView(mark, new LinearLayout.LayoutParams(dp(48), dp(40)));

        TextView title = new TextView(this);
        title.setText("AH-TRADING-PRO");
        title.setTextColor(Color.rgb(255,229,138));
        title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD_ITALIC);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,-1,1);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(8),0,0,0);
        toolbar.addView(title,tp);

        languageButton = new TextView(this);
        stylePill(languageButton);
        languageButton.setText(banglaEnabled ? "EN" : "বাংলা");
        languageButton.setOnClickListener(v -> {
            playClick();
            banglaEnabled = !banglaEnabled;
            prefs.edit().putBoolean("bangla", banglaEnabled).apply();
            languageButton.setText(banglaEnabled ? "EN" : "বাংলা");
            if (banglaEnabled) requestFullPageTranslation();
            else restoreEnglish();
        });
        toolbar.addView(languageButton, new LinearLayout.LayoutParams(dp(62),dp(36)));

        soundButton = new ImageButton(this);
        soundButton.setImageResource(soundEnabled ? android.R.drawable.ic_lock_silent_mode_off : android.R.drawable.ic_lock_silent_mode);
        soundButton.setBackgroundColor(Color.TRANSPARENT);
        soundButton.setColorFilter(Color.rgb(245,185,40));
        soundButton.setOnClickListener(v -> {
            soundEnabled = !soundEnabled;
            prefs.edit().putBoolean("sound", soundEnabled).apply();
            soundButton.setImageResource(soundEnabled ? android.R.drawable.ic_lock_silent_mode_off : android.R.drawable.ic_lock_silent_mode);
            if (soundEnabled) playClick();
        });
        toolbar.addView(soundButton, new LinearLayout.LayoutParams(dp(44),dp(44)));
        return toolbar;
    }

    private void stylePill(TextView view) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(10,20,34));
        d.setStroke(dp(1), Color.rgb(245,185,40));
        d.setCornerRadius(dp(18));
        view.setBackground(d);
        view.setTextColor(Color.rgb(245,185,40));
        view.setTextSize(12);
        view.setGravity(Gravity.CENTER);
        view.setTypeface(null, android.graphics.Typeface.BOLD);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " AHTradingProApp/1.3");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true);

        webView.addJavascriptInterface(new PageBridge(), "AHNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                showLoading(true);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                hideLoadingWithFade();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideLoadingWithFade();
                injectClickSoundBridge();
                if (banglaEnabled) requestFullPageTranslation();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                String host = uri.getHost() == null ? "" : uri.getHost();
                if (scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("sms") ||
                        scheme.equals("tg") || scheme.equals("whatsapp")) {
                    openExternal(uri);
                    return true;
                }
                if (host.endsWith("ahtradingpro.com")) return false;
                openExternal(uri);
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress >= 72) hideLoadingWithFade();
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            playClick();
            startDownload(url, userAgent, contentDisposition, mimetype);
        });
    }

    private FrameLayout buildLoadingOverlay() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.argb(238,2,6,13));
        overlay.setClickable(true);
        loadingVisible = true;

        loadingSpinner = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        loadingSpinner.setIndeterminate(true);
        loadingSpinner.setIndeterminateTintList(ColorStateList.valueOf(Color.rgb(245,185,40)));
        FrameLayout.LayoutParams spinnerParams = new FrameLayout.LayoutParams(dp(132),dp(132));
        spinnerParams.gravity = Gravity.CENTER;
        overlay.addView(loadingSpinner, spinnerParams);

        loadingLogo = new ImageView(this);
        loadingLogo.setImageResource(R.drawable.loading_mark);
        loadingLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(78),dp(78));
        ip.gravity = Gravity.CENTER;
        overlay.addView(loadingLogo, ip);

        TextView text = new TextView(this);
        text.setText("SECURE LOADING");
        text.setTextColor(Color.rgb(245,185,40));
        text.setTextSize(12);
        text.setLetterSpacing(.16f);
        text.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tx = new FrameLayout.LayoutParams(-1,dp(40));
        tx.gravity = Gravity.CENTER;
        tx.topMargin = dp(142);
        overlay.addView(text,tx);
        return overlay;
    }

    private void showLoading(boolean show) {
        if (!show) {
            hideLoadingWithFade();
            return;
        }
        runOnUiThread(() -> {
            if (loadingOverlay == null) return;
            loadingHandler.removeCallbacks(forceHideLoading);
            loadingOverlay.animate().cancel();
            loadingOverlay.setVisibility(View.VISIBLE);
            loadingOverlay.setAlpha(1f);
            loadingVisible = true;

            loadingLogo.clearAnimation();
            android.view.animation.ScaleAnimation pulse = new android.view.animation.ScaleAnimation(
                    .92f, 1.06f, .92f, 1.06f,
                    Animation.RELATIVE_TO_SELF, .5f,
                    Animation.RELATIVE_TO_SELF, .5f);
            pulse.setDuration(720);
            pulse.setRepeatCount(Animation.INFINITE);
            pulse.setRepeatMode(Animation.REVERSE);
            loadingLogo.startAnimation(pulse);

            // Never allow the loading screen to cover a usable page indefinitely.
            loadingHandler.postDelayed(forceHideLoading, 6500L);
        });
    }

    private void hideLoadingWithFade() {
        runOnUiThread(() -> {
            loadingHandler.removeCallbacks(forceHideLoading);
            if (loadingOverlay == null || !loadingVisible) return;
            loadingVisible = false;
            loadingLogo.clearAnimation();
            loadingOverlay.animate().cancel();
            loadingOverlay.animate()
                    .alpha(0f)
                    .setDuration(220L)
                    .withEndAction(() -> {
                        loadingOverlay.setVisibility(View.GONE);
                        loadingOverlay.setAlpha(1f);
                    })
                    .start();
        });
    }

    private void setupSound() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(3).setAudioAttributes(attrs).build();
        soundPool.setOnLoadCompleteListener((pool, sampleId, status) -> {
            if (sampleId == clickSound && status == 0) clickSoundReady = true;
        });
        clickSound = soundPool.load(this, R.raw.ui_click, 1);
    }

    private void playClick() {
        long now = SystemClock.elapsedRealtime();
        if (!soundEnabled || soundPool == null || !clickSoundReady || now - lastClickSoundAt < 70) return;
        lastClickSoundAt = now;
        soundPool.play(clickSound,1f,1f,1,0,1f);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void installWebViewTouchSound() {
        webView.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touchDownX = event.getX();
                touchDownY = event.getY();
                touchDownAt = SystemClock.elapsedRealtime();
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                float dx = Math.abs(event.getX() - touchDownX);
                float dy = Math.abs(event.getY() - touchDownY);
                long duration = SystemClock.elapsedRealtime() - touchDownAt;
                if (dx < dp(16) && dy < dp(16) && duration < 650) playClick();
            }
            return false;
        });
    }

    private void setupTranslator() {
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.BENGALI)
                .build();
        translator = Translation.getClient(options);
    }

    private void requestFullPageTranslation() {
        if (translator == null) return;
        showLoading(true);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> {
                    showLoading(false);
                    collectPageText();
                })
                .addOnFailureListener(e -> {
                    showLoading(false);
                    Toast.makeText(this, "বাংলা translation model download failed", Toast.LENGTH_LONG).show();
                });
    }

    private void collectPageText() {
        String js = "(function(){"+
                "if(!window.__ahOriginal){window.__ahOriginal={};}"+
                "let nodes=[];let w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;let i=0;"+
                "while((n=w.nextNode())){let t=n.nodeValue.trim();if(t.length>0&&t.length<500){let p=n.parentElement;if(!p||['SCRIPT','STYLE','NOSCRIPT','TEXTAREA'].includes(p.tagName))continue;let id='aht_'+(i++);n.__ahid=id;window.__ahOriginal[id]=n.nodeValue;nodes.push({id:id,text:t});}}"+
                "AHNative.translateBatch(JSON.stringify(nodes));})();";
        webView.evaluateJavascript(js,null);
    }

    private void restoreEnglish() {
        String js = "(function(){if(!window.__ahOriginal)return;let w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while((n=w.nextNode())){if(n.__ahid&&window.__ahOriginal[n.__ahid]!==undefined)n.nodeValue=window.__ahOriginal[n.__ahid];}})();";
        webView.evaluateJavascript(js,null);
    }

    private void injectClickSoundBridge() {
        String js = "(function(){if(window.__ahClickInstalled)return;window.__ahClickInstalled=true;"+
                "let last=0;function fire(e){let n=Date.now();if(n-last<120)return;"+
                "let el=e.target&&e.target.closest?e.target.closest('a,button,input,select,summary,[role=button],[onclick],.btn,.button'):null;"+
                "if(el){last=n;try{AHNative.playClick();}catch(x){}}}"+
                "document.addEventListener('pointerdown',fire,true);"+
                "document.addEventListener('touchstart',fire,{capture:true,passive:true});"+
                "document.addEventListener('click',fire,true);})();";
        webView.evaluateJavascript(js,null);
    }

    private class PageBridge {
        @JavascriptInterface
        public void playClick() { runOnUiThread(MainActivity.this::playClick); }

        @JavascriptInterface
        public void translateBatch(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                List<JSONObject> items = new ArrayList<>();
                for (int i=0;i<arr.length();i++) items.add(arr.getJSONObject(i));
                translateNext(items,0,new JSONArray());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Translation error",Toast.LENGTH_SHORT).show());
            }
        }
    }

    private void translateNext(List<JSONObject> items, int index, JSONArray out) {
        if (!banglaEnabled || index >= items.size()) {
            runOnUiThread(() -> applyTranslations(out));
            return;
        }
        try {
            JSONObject item = items.get(index);
            String id = item.getString("id");
            String text = item.getString("text");
            translator.translate(text)
                    .addOnSuccessListener(translated -> {
                        JSONObject r = new JSONObject();
                        try { r.put("id",id); r.put("text",translated); out.put(r); } catch (Exception ignored) { }
                        translateNext(items,index+1,out);
                    })
                    .addOnFailureListener(e -> translateNext(items,index+1,out));
        } catch (Exception e) {
            translateNext(items,index+1,out);
        }
    }

    private void applyTranslations(JSONArray arr) {
        String payload = JSONObject.quote(arr.toString());
        String js = "(function(){let a=JSON.parse("+payload+");let map={};a.forEach(x=>map[x.id]=x.text);let w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;while((n=w.nextNode())){if(n.__ahid&&map[n.__ahid])n.nodeValue=n.nodeValue.replace(n.nodeValue.trim(),map[n.__ahid]);}})();";
        webView.evaluateJavascript(js,null);
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mime) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.addRequestHeader("User-Agent",userAgent);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) request.addRequestHeader("Cookie",cookies);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            String filename = android.webkit.URLUtil.guessFileName(url,contentDisposition,mime);
            request.setTitle(filename);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,filename);
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
            Toast.makeText(this,"Download started",Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openExternal(Uri.parse(url));
        }
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
        catch (Exception e) { Toast.makeText(this,"No compatible app found",Toast.LENGTH_SHORT).show(); }
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= 23) {
            NetworkCapabilities c = cm.getNetworkCapabilities(cm.getActiveNetwork());
            return c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        }
        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    private void showOffline() {
        String html = "<html><body style='margin:0;background:#02060d;color:white;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;text-align:center'><div><h1 style='color:#f5b928'>You are offline</h1><p>Check your internet connection and try again.</p><button onclick='location.href=\""+HOME_URL+"\"' style='background:#f5b928;border:0;padding:14px 24px;border-radius:10px;font-weight:bold'>TRY AGAIN</button></div></body></html>";
        webView.loadDataWithBaseURL(HOME_URL,html,"text/html","UTF-8",null);
        showLoading(false);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setTitle("Exit AH Trading Pro?").setMessage("Do you want to close the app?")
                .setNegativeButton("Cancel",null).setPositiveButton("Exit",(d,w)->finish()).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode,data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        loadingHandler.removeCallbacksAndMessages(null);
        if (translator != null) translator.close();
        if (soundPool != null) soundPool.release();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    /**
     * Keeps the app toolbar, language selector and sound control clear of the
     * Android status and navigation bars. This is required on Android 15+
     * where edge-to-edge layout is enforced for targetSdk 35 apps.
     */
    private void applySystemBarSafeArea(View root) {
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int left;
            int top;
            int right;
            int bottom;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                left = bars.left;
                top = bars.top;
                right = bars.right;
                bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }

            view.setPadding(left, top, right, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
