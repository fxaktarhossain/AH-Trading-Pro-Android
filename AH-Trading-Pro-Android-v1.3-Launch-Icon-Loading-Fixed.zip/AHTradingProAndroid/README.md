# AH Trading Pro Android App

Website: https://ahtradingpro.com  
Package: com.ahtradingpro.app

Included:
- Professional gold/black animated splash screen
- Short startup chime
- Native click sound across app controls and injected website buttons/links
- Sound mute/unmute
- Branded animated loading overlay
- Full WebView wrapper with file upload and Android Download Manager
- External Telegram/WhatsApp/tel/mail links
- Pull-safe navigation and offline page
- Bangla/English switching using Google ML Kit on-device translation
- Bengali model downloads on first use (about 30 MB)
- GitHub Actions APK build workflow

Build locally with Android Studio or upload this project to GitHub and run the `Build Android APK` action. The generated debug APK appears as an Actions artifact.

Security notes:
- Only HTTPS is allowed.
- The JavaScript bridge exposes only click feedback and translation text, and should only be used with the trusted AH Trading Pro domain.
