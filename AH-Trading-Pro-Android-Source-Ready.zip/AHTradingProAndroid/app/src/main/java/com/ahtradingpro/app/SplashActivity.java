package com.ahtradingpro.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(2, 6, 13));
        getWindow().setNavigationBarColor(Color.rgb(2, 6, 13));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(2, 6, 13));

        ImageView glow = new ImageView(this);
        glow.setImageResource(com.ahtradingpro.app.R.drawable.gold_glow);
        glow.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(glow, new FrameLayout.LayoutParams(-1, -1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.ahtradingpro.app.R.drawable.logo_full);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(145));
        lp.gravity = Gravity.CENTER;
        lp.leftMargin = dp(26);
        lp.rightMargin = dp(26);
        root.addView(logo, lp);

        TextView subtitle = new TextView(this);
        subtitle.setText("TRADE  •  ANALYZE  •  PROFIT");
        subtitle.setTextColor(Color.rgb(245,185,40));
        subtitle.setTextSize(13);
        subtitle.setLetterSpacing(0.18f);
        subtitle.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, dp(40));
        sp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL;
        sp.topMargin = dp(145);
        root.addView(subtitle, sp);

        TextView loading = new TextView(this);
        loading.setText("Loading secure trading platform…");
        loading.setTextColor(Color.rgb(170,178,192));
        loading.setTextSize(12);
        loading.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams loadp = new FrameLayout.LayoutParams(-1, dp(44));
        loadp.gravity = Gravity.BOTTOM;
        loadp.bottomMargin = dp(38);
        root.addView(loading, loadp);

        setContentView(root);

        ScaleAnimation pulse = new ScaleAnimation(.94f, 1.03f, .94f, 1.03f,
                Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
        pulse.setDuration(900);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);
        logo.startAnimation(pulse);

        AlphaAnimation fade = new AlphaAnimation(.45f, 1f);
        fade.setDuration(800);
        fade.setRepeatMode(Animation.REVERSE);
        fade.setRepeatCount(Animation.INFINITE);
        loading.startAnimation(fade);

        try {
            player = MediaPlayer.create(this, R.raw.startup_chime);
            if (player != null) {
                player.setVolume(.45f, .45f);
                player.start();
            }
        } catch (Exception ignored) { }

        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 2500);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
