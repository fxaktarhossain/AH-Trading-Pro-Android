package com.ahtradingpro.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.onesignal.Continue;
import com.onesignal.OneSignal;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Centralized OneSignal integration. The public App ID is loaded from the website. */
public final class OneSignalManager {
    private static final String CONFIG_URL = "https://ahtradingpro.com/api/push-config.php";
    private static final String PREFS = "ahtradingpro";
    private static final String APP_ID_KEY = "onesignal_app_id";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Object INIT_LOCK = new Object();
    private static volatile boolean initialized = false;
    private static volatile boolean fetching = false;

    private OneSignalManager() { }

    /**
     * Initializes immediately from a previously cached public App ID, then refreshes the
     * configuration from the website. This keeps push registration available even when the
     * website endpoint is temporarily slow or offline.
     */
    public static void initializeFromServer(Context context) {
        Context appContext = context.getApplicationContext();
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cachedAppId = prefs.getString(APP_ID_KEY, "");
        if (isValidUuid(cachedAppId)) {
            initializeSdk(appContext, cachedAppId);
        }

        if (fetching) return;
        fetching = true;
        EXECUTOR.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(CONFIG_URL + "?_=" + System.currentTimeMillis());
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "AHTradingProApp/1.4");
                int status = connection.getResponseCode();
                if (status < 200 || status >= 300) return;

                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        connection.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                }
                JSONObject json = new JSONObject(body.toString());
                boolean enabled = json.optBoolean("enabled", false);
                String appId = json.optString("app_id", "").trim();
                if (!enabled || !isValidUuid(appId)) return;

                prefs.edit().putString(APP_ID_KEY, appId).apply();
                initializeSdk(appContext, appId);
            } catch (Exception ignored) {
                // The local website notification feed still works if remote push setup is unavailable.
            } finally {
                if (connection != null) connection.disconnect();
                fetching = false;
            }
        });
    }

    private static void initializeSdk(Context appContext, String appId) {
        if (initialized || !isValidUuid(appId)) return;
        synchronized (INIT_LOCK) {
            if (initialized) return;
            try {
                OneSignal.initWithContext(appContext, appId);
                initialized = true;
                appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit()
                        .putBoolean("push_initialized", true)
                        .putString(APP_ID_KEY, appId)
                        .apply();
            } catch (Exception ignored) {
                initialized = false;
            }
        }
    }

    public static boolean isInitialized() {
        return initialized;
    }

    public static void requestPermission(Context context) {
        if (!initialized) {
            initializeFromServer(context);
            new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context, "Push service is starting. Please tap again shortly.", Toast.LENGTH_SHORT).show());
            return;
        }
        try {
            OneSignal.getNotifications().requestPermission(true, Continue.none());
        } catch (Exception e) {
            new Handler(Looper.getMainLooper()).post(() ->
                    Toast.makeText(context, "Could not open notification permission", Toast.LENGTH_SHORT).show());
        }
    }

    private static boolean isValidUuid(String value) {
        return value != null && value.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$");
    }
}
