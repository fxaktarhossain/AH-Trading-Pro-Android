package com.ahtradingpro.app;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private static final long SPLASH_DURATION_MS = 6000L;
    private final Handler handler = new Handler();
    private MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(2, 6, 13));
        getWindow().setNavigationBarColor(Color.rgb(2, 6, 13));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        FrameLayout root = new FrameLayout(this);
        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(1, 4, 10), Color.rgb(4, 12, 24), Color.rgb(1, 4, 10)});
        root.setBackground(background);

        View ring = new View(this);
        GradientDrawable ringDrawable = new GradientDrawable();
        ringDrawable.setShape(GradientDrawable.OVAL);
        ringDrawable.setColor(Color.TRANSPARENT);
        ringDrawable.setStroke(dp(2), Color.rgb(245, 185, 40));
        ring.setBackground(ringDrawable);
        ring.setAlpha(0f);
        ring.setScaleX(.35f);
        ring.setScaleY(.35f);
        FrameLayout.LayoutParams ringParams = new FrameLayout.LayoutParams(dp(260), dp(260));
        ringParams.gravity = Gravity.CENTER;
        ringParams.bottomMargin = dp(60);
        root.addView(ring, ringParams);

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.logo_mark);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        mark.setAlpha(0f);
        mark.setScaleX(.18f);
        mark.setScaleY(.18f);
        mark.setRotation(-12f);
        FrameLayout.LayoutParams markParams = new FrameLayout.LayoutParams(dp(250), dp(250));
        markParams.gravity = Gravity.CENTER;
        markParams.bottomMargin = dp(60);
        root.addView(mark, markParams);

        ImageView fullLogo = new ImageView(this);
        fullLogo.setImageResource(R.drawable.logo_full);
        fullLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        fullLogo.setAlpha(0f);
        fullLogo.setScaleX(.82f);
        fullLogo.setScaleY(.82f);
        fullLogo.setTranslationY(dp(36));
        FrameLayout.LayoutParams fullParams = new FrameLayout.LayoutParams(-1, dp(220));
        fullParams.gravity = Gravity.CENTER;
        fullParams.leftMargin = dp(22);
        fullParams.rightMargin = dp(22);
        fullParams.bottomMargin = dp(50);
        root.addView(fullLogo, fullParams);

        TextView createdBy = new TextView(this);
        createdBy.setText("Created by : AKTAR HOSSAIN");
        createdBy.setTextColor(Color.rgb(245, 185, 40));
        createdBy.setTextSize(15);
        createdBy.setTypeface(null, android.graphics.Typeface.BOLD);
        createdBy.setGravity(Gravity.CENTER);
        createdBy.setAlpha(0f);
        FrameLayout.LayoutParams createdParams = new FrameLayout.LayoutParams(-1, dp(48));
        createdParams.gravity = Gravity.BOTTOM;
        createdParams.leftMargin = dp(20);
        createdParams.rightMargin = dp(20);
        createdParams.bottomMargin = dp(42);
        root.addView(createdBy, createdParams);

        TextView secureText = new TextView(this);
        secureText.setText("SECURE  •  FAST  •  PROFESSIONAL");
        secureText.setTextColor(Color.rgb(150, 163, 182));
        secureText.setTextSize(10);
        secureText.setLetterSpacing(.14f);
        secureText.setGravity(Gravity.CENTER);
        secureText.setAlpha(0f);
        FrameLayout.LayoutParams secureParams = new FrameLayout.LayoutParams(-1, dp(32));
        secureParams.gravity = Gravity.BOTTOM;
        secureParams.bottomMargin = dp(18);
        root.addView(secureText, secureParams);

        setContentView(root);
        playStartupSound();

        root.post(() -> startSplashAnimations(mark, fullLogo, ring, createdBy, secureText));
        handler.postDelayed(this::openHome, SPLASH_DURATION_MS);
    }

    private void startSplashAnimations(ImageView mark, ImageView fullLogo, View ring,
                                       TextView createdBy, TextView secureText) {
        ObjectAnimator markAlpha = ObjectAnimator.ofFloat(mark, View.ALPHA, 0f, 1f);
        ObjectAnimator markScaleX = ObjectAnimator.ofFloat(mark, View.SCALE_X, .18f, 1f);
        ObjectAnimator markScaleY = ObjectAnimator.ofFloat(mark, View.SCALE_Y, .18f, 1f);
        ObjectAnimator markRotation = ObjectAnimator.ofFloat(mark, View.ROTATION, -12f, 0f);
        AnimatorSet markIntro = new AnimatorSet();
        markIntro.playTogether(markAlpha, markScaleX, markScaleY, markRotation);
        markIntro.setDuration(1350);
        markIntro.setStartDelay(180);
        markIntro.setInterpolator(new OvershootInterpolator(.9f));
        markIntro.start();

        ObjectAnimator ringAlpha = ObjectAnimator.ofFloat(ring, View.ALPHA, 0f, .75f, 0f);
        ObjectAnimator ringScaleX = ObjectAnimator.ofFloat(ring, View.SCALE_X, .35f, 1.22f);
        ObjectAnimator ringScaleY = ObjectAnimator.ofFloat(ring, View.SCALE_Y, .35f, 1.22f);
        AnimatorSet ringSet = new AnimatorSet();
        ringSet.playTogether(ringAlpha, ringScaleX, ringScaleY);
        ringSet.setDuration(1900);
        ringSet.setStartDelay(180);
        ringSet.setInterpolator(new DecelerateInterpolator());
        ringSet.start();

        ObjectAnimator markExit = ObjectAnimator.ofPropertyValuesHolder(mark,
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, .72f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, .72f),
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f, -dp(34)));
        markExit.setDuration(650);
        markExit.setStartDelay(1950);
        markExit.setInterpolator(new DecelerateInterpolator());
        markExit.start();

        ObjectAnimator fullAlpha = ObjectAnimator.ofFloat(fullLogo, View.ALPHA, 0f, 1f);
        ObjectAnimator fullScaleX = ObjectAnimator.ofFloat(fullLogo, View.SCALE_X, .82f, 1f);
        ObjectAnimator fullScaleY = ObjectAnimator.ofFloat(fullLogo, View.SCALE_Y, .82f, 1f);
        ObjectAnimator fullMove = ObjectAnimator.ofFloat(fullLogo, View.TRANSLATION_Y, dp(36), 0f);
        AnimatorSet fullSet = new AnimatorSet();
        fullSet.playTogether(fullAlpha, fullScaleX, fullScaleY, fullMove);
        fullSet.setDuration(900);
        fullSet.setStartDelay(2100);
        fullSet.setInterpolator(new DecelerateInterpolator());
        fullSet.start();

        ObjectAnimator logoPulse = ObjectAnimator.ofPropertyValuesHolder(fullLogo,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.025f, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.025f, 1f));
        logoPulse.setDuration(1450);
        logoPulse.setStartDelay(3400);
        logoPulse.start();

        ObjectAnimator createdFade = ObjectAnimator.ofFloat(createdBy, View.ALPHA, 0f, 1f);
        createdFade.setDuration(700);
        createdFade.setStartDelay(3200);
        createdFade.start();

        ObjectAnimator secureFade = ObjectAnimator.ofFloat(secureText, View.ALPHA, 0f, .9f);
        secureFade.setDuration(700);
        secureFade.setStartDelay(3550);
        secureFade.start();
    }

    private void playStartupSound() {
        try {
            player = MediaPlayer.create(this, R.raw.startup_chime);
            if (player != null) {
                player.setVolume(.68f, .68f);
                player.start();
            }
        } catch (Exception ignored) { }
    }

    private void openHome() {
        if (isFinishing()) return;
        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
