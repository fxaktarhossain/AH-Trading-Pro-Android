package com.ahtradingpro.app;

import android.app.Application;

public class AHApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        OneSignalManager.initializeFromServer(this);
    }
}
