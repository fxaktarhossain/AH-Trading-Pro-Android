# AH Trading Pro Android App

Website: https://ahtradingpro.com  
Package: com.ahtradingpro.app

Included:
- Professional gold/black animated splash screen
- Short startup chime
- Native click sound across app controls and injected website buttons/links
- Sound mute/unmute
- Branded animated loading overlay
- Full WebView wrapper with file upload and Android Download Manager
- External Telegram/WhatsApp/tel/mail links
- Pull-safe navigation and offline page
- Bangla/English switching using Google ML Kit on-device translation
- Bengali model downloads on first use (about 30 MB)
- GitHub Actions APK build workflow

Build locally with Android Studio or upload this project to GitHub and run the `Build Android APK` action. The generated debug APK appears as an Actions artifact.

Security notes:
- Only HTTPS is allowed.
- The JavaScript bridge exposes only click feedback and translation text, and should only be used with the trusted AH Trading Pro domain.

## Version 1.4.0 — Admin-controlled push notifications

- OneSignal Android SDK 5.6.1 integration.
- Public OneSignal App ID is loaded from `https://ahtradingpro.com/api/push-config.php`.
- The private OneSignal App API Key remains on the PHP server and is never included in the APK.
- Android notification permission primer and native permission request.
- Notification URLs for `ahtradingpro.com` deep-link back into the app WebView.
- The website notification bell can call the native permission request through `AHNative.requestPushPermission()`.

Before testing native push, enable Android/FCM and Web platforms in the same OneSignal app, then save the OneSignal App ID and App API Key in Website Admin → Push Notifications.
